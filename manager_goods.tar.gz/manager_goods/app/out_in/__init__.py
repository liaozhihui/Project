# coding=utf-8
from flask import Blueprint
out_in=Blueprint("out_in",__name__)
from . import views