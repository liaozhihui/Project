# coding=utf-8
from flask import Blueprint
information=Blueprint("information",__name__)
from . import views